document.addEventListener("DOMContentLoaded", function (event) {
    let slider = tns({
        container: ".my-slider",
        items: 1,
        gutter: 0,
        slideBy: 1,
        // controlsPosition: "hidden",
        navPosition: "bottom",
        mouseDrag: true,
        autoplay: true,
        // autoWidth: true,
        // center: true,
        arrowKeys: true,
        // autoHeight: false,
        loop: true,
        rewind: true,
        // navContainer: 1,
        // autoplayButtonOutput: false,
        // swipeAngle: false,
        // nav: true,
        // nextButton: false,
        // navAsThumbnails: true,
        // controls: true,
        // responsive: {
        //     0: {
        //         items: 1,
        //         nav: true
        //     },
        //     768: {
        //         items: 2,
        //         nav: true
        //     },
        //     1440: {
        //         items: 3,
        //         nav: true
        //     },
        //     2208: {
        //         items: 4,
        //         nav: true
        //     },
        //     2976: {
        //         items: 5,
        //         nav: true
        //     }
        // },
    });
    //console.log("heey");
});